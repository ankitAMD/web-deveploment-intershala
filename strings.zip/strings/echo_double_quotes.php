<?php
$variable1 = 18;
echo  'I am a "string".';
?>