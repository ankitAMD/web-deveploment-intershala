<?php
$variable1 = 18;
echo  'The value of variable1 is '.$variable1;
?>