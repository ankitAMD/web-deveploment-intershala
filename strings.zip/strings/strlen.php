<?php

$string1 = "I am first string";
$length_of_string = strlen($string1);
echo $length_of_string;
?>