<?php
$variable1 = 18;
$variable2 = "I am a string.";
?>