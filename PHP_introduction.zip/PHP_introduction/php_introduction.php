<?php
echo "Hello! I want to be a web developer.";
?>