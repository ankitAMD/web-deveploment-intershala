<!DOCTYPE html>
<html>
    <head>
        <title>Variables, Data types and Operators</title>
    </head>
    <body>
        <?php
        $var1 = 18;
        $var2 = 12;
        $sum = $var1 + $var2;
        Echo $sum;
        ?>
    </body>
</html>